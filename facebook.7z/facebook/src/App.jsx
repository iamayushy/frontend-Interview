import { useState } from 'react'
import logo from './logo.svg'
import './App.css'
import {Comment} from './Components/Comment'

function App() {

  return (
    <div className="App">
     <Comment/>
    </div>
  )
}

export default App
