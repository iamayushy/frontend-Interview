import comment from '../com'
import { Box } from './Box'
const Comment = () => {

    return(
        <div>
            <Box comment = {comment}/>
            
        </div>
    )
}

export {Comment}